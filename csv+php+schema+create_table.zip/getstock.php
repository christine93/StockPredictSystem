﻿
<?PHP 

//make php be run all the time
ini_set('max_execution_time', '0');

//set the total period the same as the yahoo's stock time 
$period=390;  

//make interval one minute
$interval=60;  

//connect to the class
$stocks = new yahoo_stocks();  

//connect to database
$stocks->my_connect();
$foo = time()/60;

//do the loop to read the information of each stock from yahoo, the loop last for 390 minutes, do the loop once per minute
while(time()/60-$foo<$period) 
{
$google = $stocks->get_stocks("GOOG");

$yahoo = $stocks->get_stocks("YHOO");

$amazon = $stocks->get_stocks("AMZN");

$microsoft = $stocks->get_stocks("MSFT");

$oracle = $stocks->get_stocks("ORCL");

//delay the loop
sleep($interval);  
}
print(time()/60);

//close the database
$stocks->my_close(); 

//define a class which will be connected by the program
class yahoo_stocks {
    
    //Define variables
    public $time = "+3"; 
    public $refreshtime = "5"; 
    public $dbhost = "localhost"; 
    public $user = "root"; 
    public $passwd = "123456";  
    public $db = "yahoostocks"; 
    public $stocks_table = "STOCK";  
    public $keepfilesfor = 0;
    
    //get stocks' value to database
    function get_stocks($stock)
    {
            //transferred meaning special characters
	    $mystock = mysql_real_escape_string($stock);
 
            //select data from relational tables    
	    $q = "SELECT * FROM `$this->stocks_table` WHERE stock='$mystock' ";

            //php interface
            print("Funtion for :");
	    print($mystock);
	    print("  called");
	    print("\n");           

            //use generate_stock_array function，return the information of stocks from yahoo
     	    $return = $this->generate_stock_array($stock);
	
	    //joint character strings and insert stock information to the database
            $sql = "INSERT INTO `$this->stocks_table` (`stock` , `value` , `volume` , `open` , `high` , `low` , `date` , `time` )";
            $sql .= "VALUES('${return['stock']}','${return['value']}','${return['volume']}','${return['open']}','${return['high']}','${return['low']}',";
            $sql .= "'${return['date']}','${return['time']}')";
           
	    mysql_query($sql);
            return $return;
    } 

    //collect and deal with the stocks information from yahoo
    function generate_stock_array($stock)

    {        
        //open the csv and read it as a character string
        $open = fopen("http://finance.yahoo.com/d/quotes.csv?s=$stock&f=sl1d1t1c1ohgv&e=.csv", "r");
        
        //get rid off the " of the csv
        $read = str_replace('"', '', trim(fread($open, 2000)));
        
        //divide the char string by ',', and store them in the data array 
        $data = explode(",", $read);

        fclose($open);

        //collect the information from the csv as the formation of the dat, and put them into the $return array, and you can know about the value by key in the array.
        $strtotime_date = strtotime(str_replace('"', '', "$data[2] $data[3]"));
        
	if (preg_match("/^-.*/", $this->time)) 
	{
            $this->time = str_replace("-", "", $this->time);
            $return['unixtime'] = $strtotime_date - $this->time * 3600-9900;
        } 
	else 
	{
            $this->time = str_replace("+", "", $this->time);
            $return['unixtime'] = $strtotime_date + $this->time * 3600-9900;
        }

        $return['stock'] = $data[0];
        $return['value'] = $data[1];
        $return['date'] = date("j.n.Y", $return['unixtime']);
        $return['time'] = date("G:i", $return['unixtime']);
        $return['volume'] = $data[8];
        $return['open'] = $data[5];
        $return['high'] = $data[6];
        $return['low'] = $data[7];
        $return['md5'] = md5($read);

        return $return;
    } 

    //connect the database
    function my_connect()        
    {
        //connect db, if it dies, shows "Can't connect to mySQL"
        $this->conn = @mysql_connect($this->dbhost, $this->user, $this->passwd) or die("Can't connect to mySQL");
        
        return mysql_select_db($this->db, $this->conn);
    } 

    //close the connection to mySQL
    function my_close()

    {
        return @mysql_close();
    } 
} 
 
?> 
